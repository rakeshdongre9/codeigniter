﻿# smarttailor
 Codeigniter 3 with JWT token , Complete Authoriztion and authentication with Login | Signup api.
